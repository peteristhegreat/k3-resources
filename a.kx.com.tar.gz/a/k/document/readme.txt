welcome to the k community!

LINUX 
$HOME/k
 k		console

WIN2000/NT
c:\windows
 k.exe		console for licensed(k.lic) developers
 kr.exe		runtime for endusers(only runs .kr's)
 k20.dll	version 2(C-interface 0)
 
edit scripts with an editor, e.g. notepad c:\k\stat.k
load scripts in the console, e.g. \l stat
step through scripts in the console, e.g. \s stat

use your editor -- not the console -- to write code.
 

