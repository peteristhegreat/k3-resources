fc.k		gui: fahrenheit from centigrade
incdec.k	gui: increment decrement
nfl.k		gui: quarterback rating
tab.k		text file i/o(tab.txt)
table.k		relational table examples
timer.k		timers

calc.k		stevan apter calculator
bell.k		bell-labs benchmark
stat.k		sample statistic functions

client/server shared datasheet
 server.k
 client.k (run multiple times and change values)

