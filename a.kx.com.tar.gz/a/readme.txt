k        vector programming language

kdb      fast rdbms (SQL92, ODBC and JDBC) extended for timeseries.
         OLTP: one million inserts and updates per second (per cpu)
         OLAP: ten million rollups and analyses per second (per cpu)
         arbitrary cross-sectional timeseries and analytics in the servers

ktaq     kdb load script for http://www.nyse.com TAQ data (20+ billion trades and quotes) 
         scripts for cd's, dvd's and ftp's. symbol, split and dividend adjustments

ktick    kdb tickerplant, realtime and historical databases   
         100,000 records per second and unlimited historical data
 