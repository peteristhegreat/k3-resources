//javac k/jdbc.java  scrolling?
//2003.07.30 st getconnection (public classes for ide?)
//2002.03.27 jdbc3
package k;import java.io.*;import java.math.*;import java.util.*;import java.sql.*;import java.sql.Date;import java.net.URL;
public class jdbc implements Driver{static int V=2,v=0,inf,NI=Integer.MIN_VALUE;
public int getMajorVersion(){return V;}public int getMinorVersion(){return v;}public boolean jdbcCompliant(){return true;}
public boolean acceptsURL(String s){return s.startsWith("jdbc:kx");}
public Connection connect(String s,Properties p)throws SQLException{  //c.p(s);c.p(p);
 return!acceptsURL(s)?null:new co(s.substring(7),p!=null?p.get("user"):p,p!=null?p.get("password"):p);}  
public DriverPropertyInfo[]getPropertyInfo(String s,Properties p)throws SQLException{return new DriverPropertyInfo[0];}
static{try{DriverManager.registerDriver(new jdbc());}catch(Exception e){c.p(e.getMessage());}}
static int[]SQLTYPE={4,8,12,91,92,93,-3,1},SQLPREC={10,16,255,10,8,19,2000000000};
static String[]TYPE={"int","float","varchar","date","time","timestamp","varbinary"};
static Object ni=new Integer(NI),nf=new Double(Double.NaN),NULL[]={ni,nf,"",ni,nf,nf,null,""};
static void q(String s)throws SQLException{throw new SQLException(s);}
static void q()throws SQLException{q("nonce");}static void q(boolean b)throws SQLException{if(b)q();}
static int find(String[]x,String s){int i=0;for(;i<x.length&&!s.equals(x[i]);)++i;return i;}
static int find(int[]x,int j){int i=0;for(;i<x.length&&x[i]!=j;)++i;return i;}
static int tzo(long x){return 60000*(new java.util.Date(x)).getTimezoneOffset();}
static long lg(long x){return x-tzo(x);}static long gl(long x){long t=x+tzo(x);return t+x-lg(t);}

public class co implements Connection{private c c;
 public co(String s,Object u,Object p)throws SQLException{String m="";int j=2001;if(s.startsWith("://")){
  m=s.substring(3);int i=m.indexOf("/");if(-1<i){s=m.substring(i);m=m.substring(0,i);}else s="";
  i=m.indexOf(":");if(-1<i){j=Integer.parseInt(m.substring(i+1));m=m.substring(0,i);}}
  try{c=new c(m,j);if(u!=null&&0<c.n(u))c.k((String)u+":"+(String)p);if(1<s.length())c.k("load?",s.substring(1));}catch(Exception e){q(e.getMessage());}}
 public rs ex(String s)throws SQLException{try{return new rs((Object[])c.k(s));}catch(Exception e){q(e.getMessage());return null;}}
 private boolean a=true;private String S="";private Object[]P={};
 public void setAutoCommit(boolean b)throws SQLException{a=b;}public boolean getAutoCommit()throws SQLException{return a;}
 private Object SP(String s,Object[]p)throws SQLException{try{return 0<c.n(p)?c.ka("$"+s,p):c.k("$"+s);}catch(Exception e){q(e.getMessage());return null;}}
 public void rollback()throws SQLException{q(c==null);S="";P=new Object[0];}
 public void commit()throws SQLException{SP(S,P);rollback();}
 public Object k(String s,Object[]p)throws SQLException{if(!a)q("update only");return SP(s,p);}
 public void u(String s,Object[]p)throws SQLException{if(a)SP(s,p);else{S+=s+";";
  int m=P.length;int n=p.length;Object[]t=new Object[m+n];System.arraycopy(P,0,t,0,m);System.arraycopy(p,0,P=t,m,n);}}
 public boolean isClosed()throws SQLException{return c==null;}
 public Statement createStatement()throws SQLException{return new st(this);}
 public DatabaseMetaData getMetaData()throws SQLException{return new dm(this);} 
 public PreparedStatement prepareStatement(String s)throws SQLException{return new ps(this,s);}
 public CallableStatement prepareCall(String s)throws SQLException{return new cs(this,s);}
 public String nativeSQL(String s)throws SQLException{return s;}
 private boolean b;private int i=TRANSACTION_SERIALIZABLE,h;
 public void setReadOnly(boolean x)throws SQLException{b=x;}public boolean isReadOnly()throws SQLException{return b;}
 public void setCatalog(String s)throws SQLException{q();}public String getCatalog()throws SQLException{return"";}
 public void setTransactionIsolation(int x)throws SQLException{q(i!=x);}
 public int getTransactionIsolation()throws SQLException{return i;}
 public SQLWarning getWarnings()throws SQLException{return null;}
 public void clearWarnings()throws SQLException{}
 public void close()throws SQLException{if(c!=null)c.close();c=null;}
//2
public Statement createStatement(int resultSetType,int resultSetConcurrency)throws SQLException{q();return null;}
public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)throws SQLException{q();return null;}
public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)throws SQLException{q();return null;}
public Map getTypeMap()throws SQLException{q();return null;}
public void setTypeMap(Map map)throws SQLException{q();}
//3
public void setHoldability(int holdability)throws SQLException{h=holdability;}
public int getHoldability()throws SQLException{return h;}
public Savepoint setSavepoint()throws SQLException{q();return null;}
public Savepoint setSavepoint(String name)throws SQLException{q();return null;}
public void rollback(Savepoint savepoint)throws SQLException{}
public void releaseSavepoint(Savepoint savepoint)throws SQLException{}
public Statement createStatement(int resultSetType,int resultSetConcurrency,int resultSetHoldability)throws SQLException{q();return null;}
public PreparedStatement prepareStatement(String sql,int resultSetType,int resultSetConcurrency,int resultSetHoldability)throws SQLException{q();return null;}
public CallableStatement prepareCall(String sql,int resultSetType,int resultSetConcurrency,int resultSetHoldability)throws SQLException{q();return null;}
public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)  throws SQLException{q();return null;}
public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException{q();return null;}
public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException{q();return null;}}

public class st implements Statement{private int R;private co co;private Object[]r;protected Object[]p={};
 public st(co x){co=x;}
 public int executeUpdate(String s)throws SQLException{co.u(s,p);return -1;}
 public ResultSet executeQuery(String s)throws SQLException{return new rs((Object[])co.k(R>0?s+" rowcount "+R:s,p));}
 public boolean execute(String s)throws SQLException{return null!=(r=(Object[])co.k(s,p));}
 public ResultSet getResultSet()throws SQLException{return new rs(r);}
 public int getUpdateCount()throws SQLException{return -1;}
 public int getMaxRows()throws SQLException{return R;}public void setMaxRows(int i)throws SQLException{R=i;}
 // truncate excess BINARY,VARBINARY,LONGVARBINARY,CHAR,VARCHAR,and LONGVARCHAR fields
 public int getMaxFieldSize()throws SQLException{return inf;}public void setMaxFieldSize(int i)throws SQLException{q(i>0);}
 public int getQueryTimeout()throws SQLException{return inf;}public void setQueryTimeout(int i)throws SQLException{q(i>0);}
 public void setEscapeProcessing(boolean b)throws SQLException{}
 public void cancel()throws SQLException{q();}
 public SQLWarning getWarnings()throws SQLException{return null;}public void clearWarnings()throws SQLException{}
 // positioned update? different statement?
 public void setCursorName(String name)throws SQLException{q();}
 public boolean getMoreResults()throws SQLException{return false;}
 public void close()throws SQLException{co=null;}
//2
public void setFetchDirection(int direction)throws SQLException{q();}
public int getFetchDirection()throws SQLException{q();return 0;}
public void setFetchSize(int rows)throws SQLException{q();}
public int getFetchSize()throws SQLException{q();return 0;}
public int getResultSetConcurrency()throws SQLException{q();return 0;}
public int getResultSetType()throws SQLException{q();return 0;}
public void addBatch(String sql)throws SQLException{q();}
public void clearBatch()throws SQLException{q();}
public int[] executeBatch()throws SQLException{q();return new int[0];}
public Connection getConnection()throws SQLException{return co;}
//3
public boolean getMoreResults(int current)throws SQLException{return false;}
public ResultSet getGeneratedKeys()throws SQLException{return null;}
public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException{q();return 0;}
public int executeUpdate(String sql, int[] columnIndexes) throws SQLException{q();return 0;}
public int executeUpdate(String sql, String[] columnNames) throws SQLException{q();return 0;}
public boolean execute(String sql, int autoGeneratedKeys) throws SQLException{q();return false;}
public boolean execute(String sql, int[] columnIndexes) throws SQLException{q();return false;}
public boolean execute(String sql, String[] columnNames) throws SQLException{q();return false;}
public int getResultSetHoldability() throws SQLException{return 0;}}

public class ps extends st implements PreparedStatement{private String s;
 public ps(co co,String x){super(co);s=x;int i=0,n=0;for(;0<(i=1+x.indexOf('?',i));)++n;p=new Object[n];}
 public ResultSet executeQuery()throws SQLException{return executeQuery(s);}
 public int executeUpdate()throws SQLException{return executeUpdate(s);}
 public boolean execute()throws SQLException{return execute(s);}
 public void clearParameters()throws SQLException{for(int i=0;i<c.n(p);)p[i++]=null;}
 public void setObject(int i,Object x)throws SQLException{p[i-1]=x;}
 public void setObject(int i,Object x,int targetSqlType)throws SQLException{p[i-1]=x;}
 public void setObject(int i,Object x,int targetSqlType,int scale)throws SQLException{p[i-1]=x;}
 public void setNull(int i,int t)throws SQLException{setObject(i,NULL[find(SQLTYPE,t)]);}
 public void setInt(int i,int x)throws SQLException{setObject(i,new Integer(x));}
 public void setDouble(int i,double x)throws SQLException{setObject(i,new Double(x));}
 public void setString(int i,String x) throws SQLException{setObject(i,x);}
 public void setBytes(int i,byte x[])throws SQLException{setObject(i,x);}
 public void setDate(int i,Date x)throws SQLException{setObject(i,new Date(lg(x.getTime())));}
 public void setTime(int i,Time x)throws SQLException{setObject(i,new Time(lg(x.getTime())));}
 public void setTimestamp(int i,Timestamp x)throws SQLException{setObject(i,new Timestamp(lg(x.getTime())));}
 public void setLong(int i,long x)throws SQLException{q();}
 public void setFloat(int i,float x)throws SQLException{q();}
 public void setBigDecimal(int i,BigDecimal x)throws SQLException{q();}
 public void setBoolean(int i,boolean x)throws SQLException{q();}
 public void setByte(int i,byte x)throws SQLException{q();}
 public void setShort(int i,short x)throws SQLException{q();}
 public void setAsciiStream(int i,InputStream x,int length)throws SQLException{q();} 
 public void setUnicodeStream(int i,InputStream x,int length)throws SQLException{q();}
 public void setBinaryStream(int i,InputStream x,int length)throws SQLException{q();}
//2
public void addBatch() throws SQLException{q();}
public void setCharacterStream(int parameterIndex, Reader reader,  int length) throws SQLException{q();}
public void setRef(int i, Ref x) throws SQLException{q();}
public void setBlob(int i,Blob x) throws SQLException{q();}
public void setClob(int i,Clob x) throws SQLException{q();}
public void setArray(int i,Array x) throws SQLException{q();}
public ResultSetMetaData getMetaData() throws SQLException{q();return null;}
public void setDate(int parameterIndex,  Date x, Calendar cal) throws SQLException{q();}
public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException{q();}
public void setTimestamp(int parameterIndex, Timestamp x,  Calendar cal)  throws SQLException{q();}
public void setNull(int paramIndex, int sqlType,  String typeName) throws SQLException{q();}
//3
public void setURL(int parameterIndex, URL x) throws SQLException{q();}
public ParameterMetaData getParameterMetaData() throws SQLException{q();return null;}}

public class cs extends ps implements CallableStatement{
 public cs(co c,String s){super(c,s);}
 public void registerOutParameter(int i,int sqlType)throws SQLException{}
 public void registerOutParameter(int i,int sqlType,int scale)throws SQLException{}
 public boolean wasNull()throws SQLException{return false;}
 public String getString(int i)throws SQLException{return null;}
 public boolean getBoolean(int i)throws SQLException{return false;}
 public byte getByte(int i)throws SQLException{return 0;}
 public short getShort(int i)throws SQLException{return 0;}
 public int getInt(int i)throws SQLException{return 0;}
 public long getLong(int i)throws SQLException{return 0;}
 public float getFloat(int i)throws SQLException{return(float)0.0;}
 public double getDouble(int i)throws SQLException{return 0.0;}
 public BigDecimal getBigDecimal(int i,int scale)throws SQLException{return null;}
 public byte[]getBytes(int i)throws SQLException{return null;}
 public Date getDate(int i)throws SQLException{return null;}
 public Time getTime(int i)throws SQLException{return null;}
 public Timestamp getTimestamp(int i)throws SQLException{return null;} 
 public Object getObject(int i)throws SQLException{return null;}
//2
public BigDecimal getBigDecimal(int parameterIndex) throws SQLException{q();return null;}
public Object getObject(int i,  Map map) throws SQLException{q();return null;}
public Ref getRef(int i) throws SQLException{q();return null;}
public Blob getBlob(int i) throws SQLException{q();return null;}
public Clob getClob(int i) throws SQLException{q();return null;}
public Array getArray(int i) throws SQLException{q();return null;}
public Date getDate(int parameterIndex, Calendar cal)  throws SQLException{q();return null;}
public Time getTime(int parameterIndex, Calendar cal) throws SQLException{q();return null;} 
public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException{q();return null;}
public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException{q();}
//3
public void registerOutParameter(String parameterName, int sqlType) throws SQLException{q();}
public void registerOutParameter(String parameterName,  int sqlType, int scale) throws SQLException{q();}
public void registerOutParameter(String parameterName,  int sqlType, String typeName) throws SQLException{q();}
public URL getURL(int parameterIndex)throws SQLException{q();return null;}
public void setURL(String parameterName, URL val) throws SQLException{q();}
public void setNull(String parameterName, int sqlType) throws SQLException{q();}
public void setBoolean(String parameterName, boolean x) throws SQLException{q();}
public void setByte(String parameterName, byte x) throws SQLException{q();}
public void setShort(String parameterName, short x) throws SQLException{q();}
public void setInt(String parameterName, int x) throws SQLException{q();}
public void setLong(String parameterName, long x) throws SQLException{q();}
public void setFloat(String parameterName, float x) throws SQLException{q();}
public void setDouble(String parameterName, double x) throws SQLException{q();} 
public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException{q();}
public void setString(String parameterName, String x) throws SQLException{q();}
public void setBytes(String parameterName, byte[] x) throws SQLException{q();}
public void setDate(String parameterName, Date x) throws SQLException{q();}
public void setTime(String parameterName, Time x) throws SQLException{q();}
public void setTimestamp(String parameterName, Timestamp x) throws SQLException{q();}
public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException{q();}
public void setBinaryStream(String parameterName,  InputStream x,  int length)  throws SQLException{q();}
public void setObject(String parameterName,  Object x, int targetSqlType, int scale) throws SQLException{q();}
public void setObject(String parameterName,  Object x,  int targetSqlType)  throws SQLException{q();}
public void setObject(String parameterName,  Object x) throws SQLException{q();}
public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException{q();}
public void setDate(String parameterName, Date x, Calendar cal) throws SQLException{q();}
public void setTime(String parameterName, Time x, Calendar cal) throws SQLException{q();}
public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException{q();}
public void setNull(String parameterName,  int sqlType,  String typeName) throws SQLException{q();}
public String getString(String parameterName) throws SQLException{return null;}
public boolean getBoolean(String parameterName)throws SQLException{return false;}
public byte getByte(String parameterName)  throws SQLException{return 0;}
public short getShort(String parameterName) throws SQLException{return 0;} 
public int getInt(String parameterName) throws SQLException{return 0;} 
public long getLong(String parameterName) throws SQLException{return 0;}
public float getFloat(String parameterName) throws SQLException{return 0;}
public double getDouble(String parameterName) throws SQLException{return 0;}
public byte[] getBytes(String parameterName)throws SQLException{return null;}
public Date getDate(String parameterName)   throws SQLException{return null;}
public Time getTime(String parameterName)   throws SQLException{return null;}
public Timestamp getTimestamp(String parameterName)    throws SQLException{return null;}
public Object getObject(String parameterName)  throws SQLException{return null;} 
public BigDecimal getBigDecimal(String parameterName) throws SQLException{return null;} 
public Object getObject(String parameterName,  Map map) throws SQLException{return null;}
public Ref getRef(String parameterName)   throws SQLException{return null;}
public Blob getBlob(String parameterName)  throws SQLException{return null;}
public Clob getClob(String parameterName) throws SQLException{return null;}
public Array getArray(String parameterName) throws SQLException{return null;}
public Date getDate(String parameterName,    Calendar cal)  throws SQLException{return null;}
public Time getTime(String parameterName,    Calendar cal) throws SQLException{return null;}
public Timestamp getTimestamp(String parameterName,  Calendar cal) throws SQLException{return null;} 
public URL getURL(String parameterName)  throws SQLException{return null;}}

public class rs implements ResultSet{private boolean b;private String[]f,t;private Object[]d;private int r,n;
 public rs(Object[]x)throws SQLException{r=-1;f=(String[])x[0];d=(Object[])x[1];t=(String[])x[2];n=c.n(d[0]);} // null result?
 public ResultSetMetaData getMetaData()throws SQLException{return new rm(f,t);}
 public int findColumn(String s)throws SQLException{return 1+find(f,s);}
 public boolean next()throws SQLException{return d!=null&&++r<n;}
 public boolean wasNull()throws SQLException{return b;}
 public Object getObject(int i)throws SQLException{String s=t[i-1];q(r<0||r>=n);
  if(s.equals("varchar")){String t=((String[])d[i-1])[r];b=0==t.length();return t;}
  if(s.equals("int")){int x=getInt(i);return b?null:new Integer(x);}
  if(s.equals("float")){double x=getDouble(i);return b?null:new Double(x);}
  return s.equals("date")?getDate(i):s.equals("time")?getTime(i):s.equals("timestamp")?getTimestamp(i):(Object)getBytes(i);}
 public int getInt(int i)throws SQLException{int x=((int[])d[i-1])[r];b=NI==x;return x;}
 public double getDouble(int i)throws SQLException{double x=((double[])d[i-1])[r];b=Double.isNaN(x);return x;}
 public String getString(int i)throws SQLException{Object x=getObject(i);return x==null?null:x.toString();}
 public Date getDate(int i)throws SQLException{int x=getInt(i);return b?null:new Date(gl(86400000L*(23741+x)));}
 public Time getTime(int i)throws SQLException{double x=getDouble(i);return b?null:new Time(gl((long)(.5+8.64e7*x)));}
 public Timestamp getTimestamp(int i)throws SQLException{double x=t[i-1].equals("date")?(double)getInt(i):getDouble(i);
  return b?null:new Timestamp(gl((long)(.5+8.64e7*(23741+x))));}
 public byte[]getBytes(int i)throws SQLException{Object x=((Object[])d[i-1])[r];b=x==null;return(byte[])x;}
 public short getShort(int i)throws SQLException{return(short)getInt(i);}
 public boolean getBoolean(int i)throws SQLException{return 0!=getInt(i);}
 public BigDecimal getBigDecimal(int i,int scale)throws SQLException{q();return null;}
 public byte getByte(int i)throws SQLException{q();return 0;}
 public long getLong(int i)throws SQLException{q();return 0;}
 public float getFloat(int i)throws SQLException{q();return 0;}
 public InputStream getAsciiStream(int i)throws SQLException{q();return null;}
 public InputStream getUnicodeStream(int i)throws SQLException{q();return null;}
 public InputStream getBinaryStream(int i)throws SQLException{q();return null;}
 public Object getObject(String s)throws SQLException{return getObject(findColumn(s));}
 public int getInt(String s)throws SQLException{return getInt(findColumn(s));}
 public double getDouble(String s)throws SQLException{return getDouble(findColumn(s));}
 public String getString(String s)throws SQLException{return getString(findColumn(s));}
 public Date getDate(String s)throws SQLException{return getDate(findColumn(s));}
 public Time getTime(String s)throws SQLException{return getTime(findColumn(s));}
 public Timestamp getTimestamp(String s)throws SQLException{return getTimestamp(findColumn(s));}
 public byte[]getBytes(String s)throws SQLException{return getBytes(findColumn(s));}
 public BigDecimal getBigDecimal(String s,int scale)throws SQLException{return getBigDecimal(findColumn(s),scale);}
 public boolean getBoolean(String s)throws SQLException{return getBoolean(findColumn(s));}
 public byte getByte(String s)throws SQLException{return getByte(findColumn(s));}
 public short getShort(String s)throws SQLException{return getShort(findColumn(s));} 
 public long getLong(String s)throws SQLException{return getLong(findColumn(s));}
 public float getFloat(String s)throws SQLException{return getFloat(findColumn(s));}
 public InputStream getAsciiStream(String s)throws SQLException{return getAsciiStream(findColumn(s));}
 public InputStream getUnicodeStream(String s)throws SQLException{return getUnicodeStream(findColumn(s));}
 public InputStream getBinaryStream(String s)throws SQLException{return getBinaryStream(findColumn(s));}
 public SQLWarning getWarnings()throws SQLException{return null;}public void clearWarnings()throws SQLException{}
 public String getCursorName()throws SQLException{q();return null;}
 public void close()throws SQLException{d=null;r=-1;}
//2
public Reader getCharacterStream(int columnIndex) throws SQLException{q();return null;}
public Reader getCharacterStream(String columnName) throws SQLException{q();return null;}
public BigDecimal getBigDecimal(int columnIndex)throws SQLException{q();return null;}
public BigDecimal getBigDecimal(String columnName)throws SQLException{q();return null;}
public boolean isBeforeFirst()throws SQLException{q();return false;}
public boolean isAfterLast()throws SQLException{q();return false;}
public boolean isFirst()throws SQLException{q();return false;}
public boolean isLast()throws SQLException{q();return false;}
public void beforeFirst()throws SQLException{q();}
public void afterLast()throws SQLException{q();}
public boolean first()throws SQLException{q();return false;}
public boolean last()throws SQLException{q();return false;}
public int getRow()throws SQLException{q();return 0;}
public boolean absolute(int row)throws SQLException{q();return false;}
public boolean relative(int rows)throws SQLException{q();return false;}
public boolean previous()throws SQLException{q();return false;}
public void setFetchDirection(int direction)throws SQLException{q();}
public int getFetchDirection()throws SQLException{q();return 0;}
public void setFetchSize(int rows)throws SQLException{q();}
public int getFetchSize()throws SQLException{q();return 0;}
public int getType()throws SQLException{q();return 0;}
public int getConcurrency()throws SQLException{q();return 0;}
public boolean rowUpdated()throws SQLException{q();return false;}
public boolean rowInserted()throws SQLException{q();return false;}
public boolean rowDeleted()throws SQLException{q();return false;}
public void updateNull(int columnIndex)throws SQLException{q();}
public void updateBoolean(int columnIndex, boolean x)throws SQLException{q();}
public void updateByte(int columnIndex,  byte x)throws SQLException{q();}
public void updateShort(int columnIndex,  short x)throws SQLException{q();}
public void updateInt(int columnIndex,  int x)throws SQLException{q();}
public void updateLong(int columnIndex,  long x)throws SQLException{q();}
public void updateFloat(int columnIndex, float x)throws SQLException{q();}
public void updateDouble(int columnIndex,  double x)throws SQLException{q();}
public void updateBigDecimal(int columnIndex,  BigDecimal x)throws SQLException{q();}
public void updateString(int columnIndex,  String x)throws SQLException{q();}
public void updateBytes(int columnIndex,  byte[] x)throws SQLException{q();}
public void updateDate(int columnIndex, Date x)throws SQLException{q();}
public void updateTime(int columnIndex,Time x)throws SQLException{q();}
public void updateTimestamp(int columnIndex,  Timestamp x)throws SQLException{q();}
public void updateAsciiStream(int columnIndex,  InputStream x, int length)throws SQLException{q();}
public void updateBinaryStream(int columnIndex,  InputStream x, int length)throws SQLException{q();}
public void updateCharacterStream(int columnIndex, Reader x, int length)throws SQLException{q();}
public void updateObject(int columnIndex,  Object x,  int scale)throws SQLException{q();}
public void updateObject(int columnIndex, Object x)throws SQLException{q();}
public void updateNull(String columnName)throws SQLException{q();}
public void updateBoolean(String columnName,  boolean x)throws SQLException{q();}
public void updateByte(String columnName, byte x)throws SQLException{q();}
public void updateShort(String columnName,  short x)throws SQLException{q();}
public void updateInt(String columnName, int x)throws SQLException{q();}
public void updateLong(String columnName, long x)throws SQLException{q();}
public void updateFloat(String columnName, float x)throws SQLException{q();}
public void updateDouble(String columnName, double x)throws SQLException{q();}
public void updateBigDecimal(String columnName, BigDecimal x)throws SQLException{q();}
public void updateString(String columnName,  String x)throws SQLException{q();}
public void updateBytes(String columnName,  byte[] x)throws SQLException{q();}
public void updateDate(String columnName, Date x)throws SQLException{q();}
public void updateTime(String columnName, Time x)throws SQLException{q();}
public void updateTimestamp(String columnName, Timestamp x)throws SQLException{q();}
public void updateAsciiStream(String columnName, InputStream x, int length)throws SQLException{q();}
public void updateBinaryStream(String columnName,  InputStream x, int length)throws SQLException{q();}
public void updateCharacterStream(String columnName, Reader reader,  int length)throws SQLException{q();}
public void updateObject(String columnName,  Object x,  int scale)throws SQLException{q();}
public void updateObject(String columnName,  Object x)throws SQLException{q();}
public void insertRow()throws SQLException{q();}
public void updateRow()throws SQLException{q();}
public void deleteRow()throws SQLException{q();}
public void refreshRow()throws SQLException{q();}
public void cancelRowUpdates()throws SQLException{q();}
public void moveToInsertRow() throws SQLException{q();}
public void moveToCurrentRow()throws SQLException{q();}
public Statement getStatement()throws SQLException{q();return null;}
public Object getObject(int i, Map map)throws SQLException{q();return null;}
public Ref getRef(int i)throws SQLException{q();return null;}
public Blob getBlob(int i)throws SQLException{q();return null;}
public Clob getClob(int i)throws SQLException{q();return null;}
public Array getArray(int i)throws SQLException{q();return null;}
public Object getObject(String colName,   Map map)throws SQLException{q();return null;}
public Ref getRef(String colName)throws SQLException{q();return null;}
public Blob getBlob(String colName)throws SQLException{q();return null;}
public Clob getClob(String colName)throws SQLException{q();return null;}
public Array getArray(String colName)throws SQLException{q();return null;}
public Date getDate(int columnIndex,  Calendar cal)throws SQLException{q();return null;}
public Date getDate(String columnName, Calendar cal)throws SQLException{q();return null;}
public Time getTime(int columnIndex, Calendar cal)throws SQLException{q();return null;}
public Time getTime(String columnName,  Calendar cal)throws SQLException{q();return null;}
public Timestamp getTimestamp(int columnIndex, Calendar cal)throws SQLException{q();return null;}
public Timestamp getTimestamp(String columnName, Calendar cal)throws SQLException{q();return null;}
//3
public URL getURL(int columnIndex)throws SQLException{return null;}
public URL getURL(String columnName) throws SQLException{return null;}
public void updateRef(int columnIndex, Ref x) throws SQLException{q();}
public void updateRef(String columnName, Ref x)  throws SQLException{q();}
public void updateBlob(int columnIndex,  Blob x)  throws SQLException{q();}
public void updateBlob(String columnName,   Blob x) throws SQLException{q();}
public void updateClob(int columnIndex, Clob x) throws SQLException{q();}
public void updateClob(String columnName,    Clob x) throws SQLException{q();}
public void updateArray(int columnIndex,   Array x) throws SQLException{q();}
public void updateArray(String columnName, Array x) throws SQLException{q();}}

public class rm implements ResultSetMetaData{private String[]f,t;
 public rm(String[]x,String[]y){f=x;t=y;}
 public int getColumnCount()throws SQLException{return f.length;}
 public String getColumnName(int i)throws SQLException{return f[i-1];}
 public String getColumnTypeName(int i)throws SQLException{return t[i-1];}
 public int getColumnDisplaySize(int i)throws SQLException{return 11;}
 public int getScale(int i)throws SQLException{return 2;}
 public int isNullable(int i)throws SQLException{return 1;}
 public String getColumnLabel(int i)throws SQLException{return getColumnName(i);}
 public int getColumnType(int i)throws SQLException{return SQLTYPE[find(TYPE,t[i-1])];} 
 public int getPrecision(int i)throws SQLException{return SQLPREC[find(TYPE,t[i-1])];}
 public boolean isSigned(int i)throws SQLException{return true;}
 public String getTableName(int i)throws SQLException{return"";}
 public String getSchemaName(int i)throws SQLException{return"";} 
 public String getCatalogName(int i)throws SQLException{return"";}
 public boolean isReadOnly(int i)throws SQLException{return false;}
 public boolean isWritable(int i)throws SQLException{return false;}
 public boolean isDefinitelyWritable(int i)throws SQLException{return false;}
 public boolean isAutoIncrement(int i)throws SQLException{return false;}
 public boolean isCaseSensitive(int i)throws SQLException{return true;}
 public boolean isSearchable(int i)throws SQLException{return false;}
 public boolean isCurrency(int i)throws SQLException{return false;}
//2
public String getColumnClassName(int column)throws SQLException{q();return null;}}

public class dm implements DatabaseMetaData{private co co;public dm(co x){co=x;}
 public ResultSet getCatalogs()throws SQLException{return co.ex("([]TABLE_CAT:varchar())");}
 public ResultSet getSchemas()throws SQLException{return co.ex("([]TABLE_SCHEM:varchar())");}
 public ResultSet getTableTypes()throws SQLException{return co.ex("([]TABLE_TYPE:('TABLE','VIEW'))");}
 public ResultSet getTables(String a,String b,String t,String types[])throws SQLException{return co.ex(
  "([]TABLE_CAT:'',TABLE_SCHEM:'',TABLE_NAME:tables,TABLE_TYPE:'TABLE')union([]TABLE_NAME:views,TABLE_TYPE:'VIEW')");}
 public ResultSet getTypeInfo()throws SQLException{return co.ex(
  "'DATA_TYPE'asc([TYPE_NAME:('int','float','varchar','date','time','timestamp','varbinary')]DATA_TYPE:(4,8,12,91,92,93,-3),PRECISION:(10,16,255,10,8,19,2000000000),LITERAL_PREFIX:('','','''','date''','time''','timestamp''','0x'),LITERAL_SUFFIX:('','','''','''','''','''',''),CREATE_PARAMS:'',NULLABLE:1,CASE_SENSITIVE:1,SEARCHABLE:(2,2,3,2,2,2,1),UNSIGNED_ATTRIBUTE:0,FIXED_PREC_SCALE:0,AUTO_INCREMENT:0,LOCAL_TYPE_NAME:'',MINIMUM_SCALE:0,MAXIMUM_SCALE:0,SQL_DATA_TYPE:0,SQL_DATETIME_SUB:0,NUM_PREC_RADIX:10)");}
 public ResultSet getColumns(String a,String b,String t,String c)throws SQLException{return co.ex(
  "select TABLE_CAT:'',TABLE_SCHEM:'',TABLE_NAME:'"+t+"',COLUMN_NAME:name,DATA_TYPE:([x:('int','float','varchar','date','time','timestamp','varbinary')]y:(4,8,12,91,92,93,-3,1111))[T].y,TYPE_NAME:T,COLUMN_SIZE:2000000000,BUFFER_LENGTH:0,DECIMAL_DIGITS:16,NUM_PREC_RADIX:10,NULLABLE:1,REMARKS:'',COLUMN_DEF:'',SQL_DATA_TYPE:0,SQL_DATETIME_SUB:0,CHAR_OCTET_LENGTH:2000000000,ORDINAL_POSITION:1+asc count T,nullable:'YES'from meta "+t);}
 public ResultSet getPrimaryKeys(String a,String b,String t)throws SQLException{return co.ex(
  "([]TABLE_CAT:'',TABLE_SCHEM:'',TABLE_NAME:'"+t+"',COLUMN_NAME:key "+t+",KEY_SEQ:1+asc count key "+t+",PK_NAME:'')");}
 public ResultSet getImportedKeys(String a,String b,String t)throws SQLException{return co.ex(
  "select PKTABLE_CAT:'',PKTABLE_SCHEM:'',PKTABLE_NAME:x,PKCOLUMN_NAME:first each key each x,FKTABLE_CAT:'',FKTABLE_SCHEM:'',FKTABLE_NAME:'"+t+"',FKCOLUMN_NAME:y,KEY_SEQ:1,UPDATE_RULE:1,DELETE_RULE:0,FK_NAME:'',PK_NAME:'',DEFERRABILITY:0 from('x','y')vars fkey "+t);}
 public ResultSet getProcedures(String a,String b,String p)throws SQLException{return co.ex(
  "([]PROCEDURE_CAT:'',PROCEDURE_SCHEM:'',PROCEDURE_NAME:varchar(),r0:0,r1:0,r2:0,REMARKS:'',PROCEDURE_TYPE:0)");}
 public ResultSet getExportedKeys(String a,String b,String t)throws SQLException{q();return null;}
 public ResultSet getCrossReference(String pa,String pb,String pt,String fa,String fb,String ft)throws SQLException{q();return null;} 
 public ResultSet getIndexInfo(String a,String b,String t,boolean unique,boolean approximate)throws SQLException{q();return null;}
 public ResultSet getProcedureColumns(String a,String b,String p,String c)throws SQLException{q();return null;}
// PROCEDURE_CAT PROCEDURE_SCHEM PROCEDURE_NAME ... 
 public ResultSet getColumnPrivileges(String a,String b,String table,String columnNamePattern)throws SQLException{q();return null;}
//select TABLE_CAT TABLE_SCHEM TABLE_NAME COLUMN_NAME GRANTOR GRANTEE PRIVILEGE IS_GRANTABLE ordered by COLUMN_NAME and PRIVILEGE. 
 public ResultSet getTablePrivileges(String a,String b,String t)throws SQLException{q();return null;}
//select TABLE_CAT TABLE_SCHEM TABLE_NAME GRANTOR GRANTEE PRIVILEGE IS_GRANTABLE ordered by TABLE_SCHEM,TABLE_NAME,and PRIVILEGE. 
 public ResultSet getBestRowIdentifier(String a,String b,String t,int scope,boolean nullable)throws SQLException{q();return null;}
//select SCOPE COLUMN_NAME DATA_TYPE TYPE_NAME COLUMN_SIZE DECIMAL_DIGITS PSEUDO_COLUMN ordered by SCOPE
 public ResultSet getVersionColumns(String a,String b,String t)throws SQLException{q();return null;} 
//select SCOPE COLUMN_NAME DATA_TYPE TYPE_NAME COLUMN_SIZE DECIMAL_DIGITS PSEUDO_COLUMN ordered by SCOPE
 public boolean allProceduresAreCallable()throws SQLException{return true;}
 public boolean allTablesAreSelectable()throws SQLException{return true;}
 public boolean dataDefinitionCausesTransactionCommit()throws SQLException{return false;}
 public boolean dataDefinitionIgnoredInTransactions()throws SQLException{return false;}
 public boolean doesMaxRowSizeIncludeBlobs()throws SQLException{return true;}
 public String getSchemaTerm()throws SQLException{return"schema";}
 public String getProcedureTerm()throws SQLException{return"procedure";}
 public String getCatalogTerm()throws SQLException{return"catalog";}
 public String getCatalogSeparator()throws SQLException{return".";}
 public int getMaxBinaryLiteralLength()throws SQLException{return inf;}
 public int getMaxCharLiteralLength()throws SQLException{return inf;}
 public int getMaxColumnNameLength()throws SQLException{return inf;}
 public int getMaxColumnsInGroupBy()throws SQLException{return inf;}
 public int getMaxColumnsInIndex()throws SQLException{return inf;}
 public int getMaxColumnsInOrderBy()throws SQLException{return inf;}
 public int getMaxColumnsInSelect()throws SQLException{return inf;}
 public int getMaxColumnsInTable()throws SQLException{return inf;}
 public int getMaxConnections()throws SQLException{return inf;}
 public int getMaxCursorNameLength()throws SQLException{return inf;}
 public int getMaxIndexLength()throws SQLException{return inf;}
 public int getMaxSchemaNameLength()throws SQLException{return inf;}
 public int getMaxProcedureNameLength()throws SQLException{return inf;}
 public int getMaxCatalogNameLength()throws SQLException{return inf;}
 public int getMaxRowSize()throws SQLException{return inf;}
 public int getMaxStatementLength()throws SQLException{return inf;}
 public int getMaxStatements()throws SQLException{return inf;}
 public int getMaxTableNameLength()throws SQLException{return inf;}
 public int getMaxTablesInSelect()throws SQLException{return inf;}
 public int getMaxUserNameLength()throws SQLException{return inf;}
 public int getDefaultTransactionIsolation()throws SQLException{return co.TRANSACTION_SERIALIZABLE;}
 public String getSQLKeywords()throws SQLException{return"show,meta,vars,load,save";}
 public String getNumericFunctions()throws SQLException{return"";}
 public String getStringFunctions()throws SQLException{return"";}
 public String getSystemFunctions()throws SQLException{return"";}
 public String getTimeDateFunctions()throws SQLException{return"current_date,current_time,current_timestamp,extract,second,minute,hour,day,month,year";}
 public String getSearchStringEscape()throws SQLException{return"";}
 public String getExtraNameCharacters()throws SQLException{return"";}
 public String getIdentifierQuoteString()throws SQLException{return"";}
 public String getURL()throws SQLException{return null;}
 public String getUserName()throws SQLException{return"";}
 public String getDatabaseProductName()throws SQLException{return"kdb";}
 public String getDatabaseProductVersion()throws SQLException{return"2.0";}
 public String getDriverName()throws SQLException{return"jdbc";}
 public String getDriverVersion()throws SQLException{return V+"."+v;}
 public int getDriverMajorVersion(){return V;}
 public int getDriverMinorVersion(){return v;}
 public boolean isCatalogAtStart()throws SQLException{return true;} 
 public boolean isReadOnly()throws SQLException{return false;}
 public boolean nullsAreSortedHigh()throws SQLException{return false;}
 public boolean nullsAreSortedLow()throws SQLException{return true;}
 public boolean nullsAreSortedAtStart()throws SQLException{return false;}
 public boolean nullsAreSortedAtEnd()throws SQLException{return false;}
 public boolean supportsMixedCaseIdentifiers()throws SQLException{return false;}
 public boolean storesUpperCaseIdentifiers()throws SQLException{return false;}
 public boolean storesLowerCaseIdentifiers()throws SQLException{return false;}
 public boolean storesMixedCaseIdentifiers()throws SQLException{return true;}
 public boolean supportsMixedCaseQuotedIdentifiers()throws SQLException{return true;}
 public boolean storesUpperCaseQuotedIdentifiers()throws SQLException{return false;}
 public boolean storesLowerCaseQuotedIdentifiers()throws SQLException{return false;}
 public boolean storesMixedCaseQuotedIdentifiers()throws SQLException{return true;}
 public boolean supportsAlterTableWithAddColumn()throws SQLException{return true;}
 public boolean supportsAlterTableWithDropColumn()throws SQLException{return true;}
 public boolean supportsTableCorrelationNames()throws SQLException{return true;}
 public boolean supportsDifferentTableCorrelationNames()throws SQLException{return true;} 
 public boolean supportsColumnAliasing()throws SQLException{return true;}
 public boolean nullPlusNonNullIsNull()throws SQLException{return true;}
 public boolean supportsExpressionsInOrderBy()throws SQLException{return true;}
 public boolean supportsOrderByUnrelated()throws SQLException{return false;}
 public boolean supportsGroupBy()throws SQLException{return true;}
 public boolean supportsGroupByUnrelated()throws SQLException{return false;}
 public boolean supportsGroupByBeyondSelect()throws SQLException{return false;}
 public boolean supportsLikeEscapeClause()throws SQLException{return false;}
 public boolean supportsMultipleResultSets()throws SQLException{return false;} 
 public boolean supportsMultipleTransactions()throws SQLException{return false;} 
 public boolean supportsNonNullableColumns()throws SQLException{return true;}
 public boolean supportsMinimumSQLGrammar()throws SQLException{return true;}
 public boolean supportsCoreSQLGrammar()throws SQLException{return true;}
 public boolean supportsExtendedSQLGrammar()throws SQLException{return false;}
 public boolean supportsANSI92EntryLevelSQL()throws SQLException{return true;}
 public boolean supportsANSI92IntermediateSQL()throws SQLException{return false;}
 public boolean supportsANSI92FullSQL()throws SQLException{return false;}
 public boolean supportsIntegrityEnhancementFacility()throws SQLException{return false;}
 public boolean supportsOuterJoins()throws SQLException{return false;}
 public boolean supportsFullOuterJoins()throws SQLException{return false;}
 public boolean supportsLimitedOuterJoins()throws SQLException{return false;}
 public boolean supportsConvert()throws SQLException{return false;} 
 public boolean supportsConvert(int fromType,int toType)throws SQLException{return false;}
 public boolean supportsSchemasInDataManipulation()throws SQLException{return false;}
 public boolean supportsSchemasInProcedureCalls()throws SQLException{return false;}
 public boolean supportsSchemasInTableDefinitions()throws SQLException{return false;}
 public boolean supportsSchemasInIndexDefinitions()throws SQLException{return false;}
 public boolean supportsSchemasInPrivilegeDefinitions()throws SQLException{return false;}
 public boolean supportsCatalogsInDataManipulation()throws SQLException{return false;}
 public boolean supportsCatalogsInProcedureCalls()throws SQLException{return false;}
 public boolean supportsCatalogsInTableDefinitions()throws SQLException{return false;}
 public boolean supportsCatalogsInIndexDefinitions()throws SQLException{return false;}
 public boolean supportsCatalogsInPrivilegeDefinitions()throws SQLException{return false;}
 public boolean supportsSelectForUpdate()throws SQLException{return false;}
 public boolean supportsPositionedDelete()throws SQLException{return false;}
 public boolean supportsPositionedUpdate()throws SQLException{return false;}
 public boolean supportsOpenCursorsAcrossCommit()throws SQLException{return true;}
 public boolean supportsOpenCursorsAcrossRollback()throws SQLException{return true;}
 public boolean supportsOpenStatementsAcrossCommit()throws SQLException{return true;}
 public boolean supportsOpenStatementsAcrossRollback()throws SQLException{return true;}
 public boolean supportsStoredProcedures()throws SQLException{return false;}
 public boolean supportsSubqueriesInComparisons()throws SQLException{return true;}
 public boolean supportsSubqueriesInExists()throws SQLException{return true;}
 public boolean supportsSubqueriesInIns()throws SQLException{return true;}
 public boolean supportsSubqueriesInQuantifieds()throws SQLException{return true;}
 public boolean supportsCorrelatedSubqueries()throws SQLException{return true;}
 public boolean supportsUnion()throws SQLException{return true;}
 public boolean supportsUnionAll()throws SQLException{return true;}
 public boolean supportsTransactions()throws SQLException{return true;}
 public boolean supportsTransactionIsolationLevel(int level)throws SQLException{return true;}
 public boolean supportsDataDefinitionAndDataManipulationTransactions()throws SQLException{return true;}
 public boolean supportsDataManipulationTransactionsOnly()throws SQLException{return false;}
 public boolean usesLocalFiles()throws SQLException{return false;}
 public boolean usesLocalFilePerTable()throws SQLException{return false;}
//2
public boolean supportsResultSetType(int type)  throws SQLException{q();return false;}
public boolean supportsResultSetConcurrency(int type, int concurrency)throws SQLException{q();return false;}
public boolean ownUpdatesAreVisible(int type)throws SQLException{q();return false;}
public boolean ownDeletesAreVisible(int type) throws SQLException{q();return false;}
public boolean ownInsertsAreVisible(int type) throws SQLException{q();return false;}
public boolean othersUpdatesAreVisible(int type) throws SQLException{q();return false;}
public boolean othersDeletesAreVisible(int type) throws SQLException{q();return false;}
public boolean othersInsertsAreVisible(int type) throws SQLException{q();return false;}
public boolean updatesAreDetected(int type) throws SQLException{q();return false;}
public boolean deletesAreDetected(int type) throws SQLException{q();return false;}
public boolean insertsAreDetected(int type) throws SQLException{q();return false;}
public boolean supportsBatchUpdates() throws SQLException{q();return false;}
public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types)throws SQLException{q();return null;}
public Connection getConnection()throws SQLException{return co;}
//3
public boolean supportsSavepoints()  throws SQLException{return false;}
public boolean supportsNamedParameters() throws SQLException{return false;}
public boolean supportsMultipleOpenResults() throws SQLException{return false;}
public boolean supportsGetGeneratedKeys() throws SQLException{return false;}
public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern) throws SQLException{return null;}
public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern) throws SQLException{return null;}
public ResultSet getAttributes(String catalog,  String schemaPattern, String typeNamePattern, String attributeNamePattern) throws SQLException{return null;}
public boolean supportsResultSetHoldability(int holdability) throws SQLException{return false;}
public int getResultSetHoldability() throws SQLException{return 0;}
public int getDatabaseMajorVersion() throws SQLException{return 0;}
public int getDatabaseMinorVersion() throws SQLException{return 0;}
public int getJDBCMajorVersion() throws SQLException{return 0;}
public int getJDBCMinorVersion() throws SQLException{return 0;}
public int getSQLStateType() throws SQLException{return 0;}
public boolean locatorsUpdateCopy() throws SQLException{return false;}
public boolean supportsStatementPooling() throws SQLException{return false;}}}

/*
class ar implements Array{
 public String getBaseTypeName()throws SQLException{q();return null;}
 public int getBaseType() throws SQLException{q();return 0;}
 public Object getArray()throws SQLException{q();return null;}
 public Object getArray(Map map)throws SQLException{q();return null;}
 public Object getArray(long index, int count)throws SQLException{q();return null;}
 public Object getArray(long index, int count, Map map)throws SQLException{q();return null;}
 public ResultSet getResultSet() throws SQLException{q();return null;}
 public ResultSet getResultSet(Map map) throws SQLException{q();return null;}
 public ResultSet getResultSet(long index,  int count) throws SQLException{q();return null;}
 public ResultSet getResultSet(long index, int count,  Map map)throws SQLException{q();return null;}}
class bl implements Blob{
 public long length()throws SQLException{q();return 0L;}
 public byte[] getBytes(long pos, int length)throws SQLException{q();return null;}
 public InputStream getBinaryStream()throws SQLException{q();return null;}
 public long position(byte[] pattern, long start)throws SQLException{q();return 0L;}
 public long position(Blob pattern, long start)throws SQLException{q();return 0L;}}
class cl implements Clob{
 public long length()throws SQLException{q();return 0L;}
 public String getSubString(long pos, int length)throws SQLException{q();return null;}
 public Reader getCharacterStream()throws SQLException{q();return null;}
 public InputStream getAsciiStream()throws SQLException{q();return null;}
 public long position(String searchstr, long start)throws SQLException{q();return 0L;}
 public long position(Clob searchstr, long start)throws SQLException{q();return 0L;}}
class re implements Ref{public String getBaseTypeName()throws SQLException{q();return null;}}

// DriverPropertyInfo a=new DriverPropertyInfo("user",null),b=new DriverPropertyInfo("password",null),r[]=new DriverPropertyInfo[2];
// a.required=b.required=false;r[0]=a;r[1]=b;for(int i=0;i<r.length;i++)r[i].value = p.getProperty(r[i].name);return r;}   
public ResultSet getBestRowIdentifier(String a, String b, String t, int scope, boolean nullable) throws SQLException
  {return co.ex("select SCOPE:'1',COLUMN_NAME:name,DATA_TYPE:([x:('int','float','varchar','date','time','timestamp','varbinary')]
   y:(4,8,12,91,92,93,-3,1111))[T].y,TYPE_NAME:T,COLUMN_SIZE:2000000000,BUFFER_LENGTH:0,DECIMAL_DIGITS:16,PSEUDO_COLUMN:1 from meta " + t+" where name in key "+t);}
*/

