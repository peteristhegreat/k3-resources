The jdbc.zip file requires an unzipping software package.  These are available
as follows:

Linux:
  Comes with most installations.  Try running "unzip -v".  If you do not
  have it, send e-mail to linux@kx.com.

Solaris:
  The unzip package is available at www.sunfreeware.com.  These use the
  pkgadd command to install.  Different packages are available depending on
  the version of Solaris you are running.  If you need assistance, please
  send e-mail to tech@kx.com.  (Note that you will need to be logged in as
  superuser to install a package.)
